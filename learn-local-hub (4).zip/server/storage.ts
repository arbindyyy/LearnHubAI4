import { db } from "@db";
import * as schema from "@shared/schema";
import { eq, and, desc, sql, asc, like, inArray } from "drizzle-orm";

export const storage = {
  // Language related operations
  getLanguages: async () => {
    return await db.query.languages.findMany({
      where: eq(schema.languages.isActive, true),
      orderBy: asc(schema.languages.name)
    });
  },

  getLanguageByCode: async (code: string) => {
    return await db.query.languages.findFirst({
      where: eq(schema.languages.code, code as any)
    });
  },

  // Translation related operations
  getTranslation: async (languageId: number, entityType: string, entityId: number, field: string) => {
    return await db.query.translations.findFirst({
      where: and(
        eq(schema.translations.languageId, languageId),
        eq(schema.translations.entityType, entityType),
        eq(schema.translations.entityId, entityId),
        eq(schema.translations.field, field)
      )
    });
  },

  // Subject categories operations
  getSubjectCategories: async (languageId: number) => {
    const categories = await db.query.subjectCategories.findMany({
      where: eq(schema.subjectCategories.isActive, true)
    });

    // Get translations for each category
    const categoriesWithTranslations = await Promise.all(
      categories.map(async (category) => {
        const translation = await storage.getTranslation(
          languageId, 
          "subject_category", 
          category.id, 
          "name"
        );
        
        return {
          ...category,
          name: translation ? translation.value : category.code
        };
      })
    );

    return categoriesWithTranslations;
  },

  // Education levels operations
  getEducationLevels: async (languageId: number) => {
    const levels = await db.query.educationLevels.findMany({
      where: eq(schema.educationLevels.isActive, true)
    });

    // Get translations for each level
    const levelsWithTranslations = await Promise.all(
      levels.map(async (level) => {
        const translation = await storage.getTranslation(
          languageId, 
          "education_level", 
          level.id, 
          "name"
        );
        
        return {
          ...level,
          name: translation ? translation.value : level.code
        };
      })
    );

    return levelsWithTranslations;
  },

  // Course related operations
  getCourses: async (languageId: number, filters: { 
    categoryId?: number, 
    levelId?: number,
    isPopular?: boolean,
    isNew?: boolean,
    limit?: number
  } = {}) => {
    let query = db.select().from(schema.courses).where(eq(schema.courses.isActive, true));

    if (filters.categoryId) {
      query = query.where(eq(schema.courses.subjectCategoryId, filters.categoryId));
    }

    if (filters.levelId) {
      query = query.where(eq(schema.courses.educationLevelId, filters.levelId));
    }

    if (filters.isPopular) {
      query = query.where(eq(schema.courses.isPopular, true));
    }

    if (filters.isNew) {
      query = query.where(eq(schema.courses.isNew, true));
    }

    if (filters.limit) {
      query = query.limit(filters.limit);
    }

    const courses = await query.orderBy(desc(schema.courses.createdAt));

    // Get translations for each course
    const coursesWithTranslations = await Promise.all(
      courses.map(async (course) => {
        const titleTranslation = await storage.getTranslation(
          languageId, 
          "course", 
          course.id, 
          "title"
        );
        
        const descriptionTranslation = await storage.getTranslation(
          languageId, 
          "course", 
          course.id, 
          "description"
        );

        // Get subject category with translation
        const category = await db.query.subjectCategories.findFirst({
          where: eq(schema.subjectCategories.id, course.subjectCategoryId)
        });

        const categoryTranslation = category ? await storage.getTranslation(
          languageId,
          "subject_category",
          category.id,
          "name"
        ) : null;

        // Get education level with translation
        const level = await db.query.educationLevels.findFirst({
          where: eq(schema.educationLevels.id, course.educationLevelId)
        });

        const levelTranslation = level ? await storage.getTranslation(
          languageId,
          "education_level",
          level.id,
          "name"
        ) : null;
        
        return {
          ...course,
          title: titleTranslation ? titleTranslation.value : course.defaultTitle,
          description: descriptionTranslation ? descriptionTranslation.value : course.defaultDescription,
          category: {
            ...category,
            name: categoryTranslation ? categoryTranslation.value : (category?.code || '')
          },
          level: {
            ...level,
            name: levelTranslation ? levelTranslation.value : (level?.code || '')
          },
          rating: course.averageRating ? course.averageRating / 10 : null
        };
      })
    );

    return coursesWithTranslations;
  },

  getCourseBySlug: async (slug: string, languageId: number) => {
    const course = await db.query.courses.findFirst({
      where: and(
        eq(schema.courses.slug, slug),
        eq(schema.courses.isActive, true)
      )
    });

    if (!course) return null;

    const titleTranslation = await storage.getTranslation(
      languageId, 
      "course", 
      course.id, 
      "title"
    );
    
    const descriptionTranslation = await storage.getTranslation(
      languageId, 
      "course", 
      course.id, 
      "description"
    );

    // Get chapters with translations
    const chapters = await db.query.courseChapters.findMany({
      where: and(
        eq(schema.courseChapters.courseId, course.id),
        eq(schema.courseChapters.isActive, true)
      ),
      orderBy: asc(schema.courseChapters.orderIndex)
    });

    const chaptersWithTranslations = await Promise.all(
      chapters.map(async (chapter) => {
        const titleTranslation = await storage.getTranslation(
          languageId, 
          "chapter", 
          chapter.id, 
          "title"
        );
        
        const contentTranslation = await storage.getTranslation(
          languageId, 
          "chapter", 
          chapter.id, 
          "content"
        );
        
        return {
          ...chapter,
          title: titleTranslation ? titleTranslation.value : chapter.defaultTitle,
          content: contentTranslation ? contentTranslation.value : chapter.defaultContent
        };
      })
    );

    // Get category and level with translations
    const category = await db.query.subjectCategories.findFirst({
      where: eq(schema.subjectCategories.id, course.subjectCategoryId)
    });

    const categoryTranslation = category ? await storage.getTranslation(
      languageId,
      "subject_category",
      category.id,
      "name"
    ) : null;

    const level = await db.query.educationLevels.findFirst({
      where: eq(schema.educationLevels.id, course.educationLevelId)
    });

    const levelTranslation = level ? await storage.getTranslation(
      languageId,
      "education_level",
      level.id,
      "name"
    ) : null;

    return {
      ...course,
      title: titleTranslation ? titleTranslation.value : course.defaultTitle,
      description: descriptionTranslation ? descriptionTranslation.value : course.defaultDescription,
      category: {
        ...category,
        name: categoryTranslation ? categoryTranslation.value : (category?.code || '')
      },
      level: {
        ...level,
        name: levelTranslation ? levelTranslation.value : (level?.code || '')
      },
      chapters: chaptersWithTranslations,
      rating: course.averageRating ? course.averageRating / 10 : null
    };
  },

  // Quiz related operations
  getCourseQuiz: async (courseId: number, languageId: number) => {
    const questions = await db.query.quizQuestions.findMany({
      where: and(
        eq(schema.quizQuestions.courseId, courseId),
        eq(schema.quizQuestions.isActive, true)
      )
    });

    const questionsWithTranslations = await Promise.all(
      questions.map(async (question) => {
        const questionTranslation = await storage.getTranslation(
          languageId, 
          "quiz_question", 
          question.id, 
          "question"
        );

        // Process options - they're stored as JSON
        let options = [];
        try {
          options = JSON.parse(question.options as string);
          
          // Get translations for option texts if available
          options = await Promise.all(options.map(async (option: any, index: number) => {
            const optionTranslation = await storage.getTranslation(
              languageId,
              "quiz_option",
              question.id,
              `option_${index}`
            );
            
            return {
              ...option,
              text: optionTranslation ? optionTranslation.value : option.text
            };
          }));
        } catch (e) {
          console.error("Error parsing quiz options:", e);
        }
        
        return {
          ...question,
          question: questionTranslation ? questionTranslation.value : question.defaultQuestion,
          options
        };
      })
    );

    return questionsWithTranslations;
  },

  // Flashcard related operations
  getCourseFlashcards: async (courseId: number, languageId: number) => {
    const flashcards = await db.query.flashcards.findMany({
      where: and(
        eq(schema.flashcards.courseId, courseId),
        eq(schema.flashcards.isActive, true)
      )
    });

    const flashcardsWithTranslations = await Promise.all(
      flashcards.map(async (flashcard) => {
        const frontTranslation = await storage.getTranslation(
          languageId, 
          "flashcard", 
          flashcard.id, 
          "front"
        );
        
        const backTranslation = await storage.getTranslation(
          languageId, 
          "flashcard", 
          flashcard.id, 
          "back"
        );
        
        return {
          ...flashcard,
          front: frontTranslation ? frontTranslation.value : flashcard.defaultFront,
          back: backTranslation ? backTranslation.value : flashcard.defaultBack
        };
      })
    );

    return flashcardsWithTranslations;
  },

  // Interactive simulations operations
  getInteractiveSimulations: async (languageId: number, subjectCategoryId?: number) => {
    let query = db.select().from(schema.interactiveSimulations)
      .where(eq(schema.interactiveSimulations.isActive, true));

    if (subjectCategoryId) {
      query = query.where(eq(schema.interactiveSimulations.subjectCategoryId, subjectCategoryId));
    }

    const simulations = await query;

    const simulationsWithTranslations = await Promise.all(
      simulations.map(async (simulation) => {
        const nameTranslation = await storage.getTranslation(
          languageId, 
          "simulation", 
          simulation.id, 
          "name"
        );
        
        const descriptionTranslation = await storage.getTranslation(
          languageId, 
          "simulation", 
          simulation.id, 
          "description"
        );
        
        return {
          ...simulation,
          name: nameTranslation ? nameTranslation.value : simulation.name,
          description: descriptionTranslation ? descriptionTranslation.value : simulation.description
        };
      })
    );

    return simulationsWithTranslations;
  },

  // User progress tracking
  getUserProgress: async (userId: number, courseId?: number) => {
    if (courseId) {
      return await db.query.userProgress.findFirst({
        where: and(
          eq(schema.userProgress.userId, userId),
          eq(schema.userProgress.courseId, courseId)
        )
      });
    } else {
      return await db.query.userProgress.findMany({
        where: eq(schema.userProgress.userId, userId),
        orderBy: desc(schema.userProgress.lastAccessedAt)
      });
    }
  },

  updateUserProgress: async (userId: number, courseId: number, completedChapters: number) => {
    const existingProgress = await db.query.userProgress.findFirst({
      where: and(
        eq(schema.userProgress.userId, userId),
        eq(schema.userProgress.courseId, courseId)
      )
    });

    const courseDetails = await db.query.courses.findFirst({
      where: eq(schema.courses.id, courseId)
    });

    // Get total chapters count to determine if course is completed
    const chaptersCount = await db
      .select({ count: sql<number>`count(*)` })
      .from(schema.courseChapters)
      .where(eq(schema.courseChapters.courseId, courseId))
      .then(result => result[0]?.count || 0);

    const isCompleted = chaptersCount > 0 && completedChapters >= chaptersCount;

    if (existingProgress) {
      return await db.update(schema.userProgress)
        .set({ 
          completedChapters, 
          lastAccessedAt: new Date(),
          isCompleted
        })
        .where(and(
          eq(schema.userProgress.userId, userId),
          eq(schema.userProgress.courseId, courseId)
        ))
        .returning();
    } else {
      return await db.insert(schema.userProgress)
        .values({
          userId,
          courseId,
          completedChapters,
          isCompleted
        })
        .returning();
    }
  }
};

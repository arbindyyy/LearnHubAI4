import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API route prefix
  const apiPrefix = "/api";

  // Language routes
  app.get(`${apiPrefix}/languages`, async (req, res) => {
    try {
      const languages = await storage.getLanguages();
      return res.json({ languages });
    } catch (error) {
      console.error("Error fetching languages:", error);
      return res.status(500).json({ message: "Failed to fetch languages" });
    }
  });

  // Subjects routes
  app.get(`${apiPrefix}/subjects`, async (req, res) => {
    try {
      const languageId = parseInt(req.query.languageId as string) || 1; // Default to Hindi (id: 1)
      const subjects = await storage.getSubjectCategories(languageId);
      return res.json({ subjects });
    } catch (error) {
      console.error("Error fetching subjects:", error);
      return res.status(500).json({ message: "Failed to fetch subject categories" });
    }
  });

  // Education levels routes
  app.get(`${apiPrefix}/education-levels`, async (req, res) => {
    try {
      const languageId = parseInt(req.query.languageId as string) || 1; // Default to Hindi
      const levels = await storage.getEducationLevels(languageId);
      return res.json({ levels });
    } catch (error) {
      console.error("Error fetching education levels:", error);
      return res.status(500).json({ message: "Failed to fetch education levels" });
    }
  });

  // Courses routes
  app.get(`${apiPrefix}/courses`, async (req, res) => {
    try {
      const languageId = parseInt(req.query.languageId as string) || 1;
      const categoryId = req.query.categoryId ? parseInt(req.query.categoryId as string) : undefined;
      const levelId = req.query.levelId ? parseInt(req.query.levelId as string) : undefined;
      const isPopular = req.query.isPopular === 'true';
      const isNew = req.query.isNew === 'true';
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;

      const courses = await storage.getCourses(languageId, {
        categoryId,
        levelId,
        isPopular,
        isNew,
        limit
      });

      return res.json({ courses });
    } catch (error) {
      console.error("Error fetching courses:", error);
      return res.status(500).json({ message: "Failed to fetch courses" });
    }
  });

  // Course detail route
  app.get(`${apiPrefix}/courses/:slug`, async (req, res) => {
    try {
      const { slug } = req.params;
      const languageId = parseInt(req.query.languageId as string) || 1;

      const course = await storage.getCourseBySlug(slug, languageId);
      
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }

      return res.json({ course });
    } catch (error) {
      console.error("Error fetching course details:", error);
      return res.status(500).json({ message: "Failed to fetch course details" });
    }
  });

  // Course quiz route
  app.get(`${apiPrefix}/courses/:courseId/quiz`, async (req, res) => {
    try {
      const courseId = parseInt(req.params.courseId);
      const languageId = parseInt(req.query.languageId as string) || 1;

      const questions = await storage.getCourseQuiz(courseId, languageId);
      
      return res.json({ questions });
    } catch (error) {
      console.error("Error fetching quiz questions:", error);
      return res.status(500).json({ message: "Failed to fetch quiz questions" });
    }
  });

  // Course flashcards route
  app.get(`${apiPrefix}/courses/:courseId/flashcards`, async (req, res) => {
    try {
      const courseId = parseInt(req.params.courseId);
      const languageId = parseInt(req.query.languageId as string) || 1;

      const flashcards = await storage.getCourseFlashcards(courseId, languageId);
      
      return res.json({ flashcards });
    } catch (error) {
      console.error("Error fetching flashcards:", error);
      return res.status(500).json({ message: "Failed to fetch flashcards" });
    }
  });

  // Interactive simulations route
  app.get(`${apiPrefix}/interactive-simulations`, async (req, res) => {
    try {
      const languageId = parseInt(req.query.languageId as string) || 1;
      const categoryId = req.query.categoryId ? parseInt(req.query.categoryId as string) : undefined;

      const simulations = await storage.getInteractiveSimulations(languageId, categoryId);
      
      return res.json({ simulations });
    } catch (error) {
      console.error("Error fetching interactive simulations:", error);
      return res.status(500).json({ message: "Failed to fetch interactive simulations" });
    }
  });

  // User progress routes
  app.get(`${apiPrefix}/user-progress`, async (req, res) => {
    try {
      // Temporary user ID for demo purposes - in a real app, this would come from auth
      const userId = 1;
      const courseId = req.query.courseId ? parseInt(req.query.courseId as string) : undefined;

      const progress = await storage.getUserProgress(userId, courseId);
      
      return res.json({ progress });
    } catch (error) {
      console.error("Error fetching user progress:", error);
      return res.status(500).json({ message: "Failed to fetch user progress" });
    }
  });

  app.post(`${apiPrefix}/user-progress`, async (req, res) => {
    try {
      const schema = z.object({
        courseId: z.number(),
        completedChapters: z.number().min(0)
      });

      const validation = schema.safeParse(req.body);

      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid request data", 
          errors: validation.error.errors 
        });
      }

      // Temporary user ID for demo purposes
      const userId = 1;
      const { courseId, completedChapters } = validation.data;

      const updatedProgress = await storage.updateUserProgress(userId, courseId, completedChapters);
      
      return res.json({ progress: updatedProgress[0] });
    } catch (error) {
      console.error("Error updating user progress:", error);
      return res.status(500).json({ message: "Failed to update user progress" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

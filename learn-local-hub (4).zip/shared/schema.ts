import { pgTable, text, serial, integer, boolean, timestamp, json, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Enums for database
export const languageEnum = pgEnum('language', [
  'hindi', 'english', 'marathi', 'bengali', 'tamil', 'telugu', 'punjabi', 
  'gujarati', 'kannada', 'odia', 'malayalam', 'assamese', 'urdu', 'nepali', 
  'konkani', 'manipuri', 'sanskrit', 'sindhi', 'bodo', 'dogri', 'kashmiri'
]);

export const subjectCategoryEnum = pgEnum('subject_category', [
  'mathematics', 'science', 'history', 'language', 'geography', 'computer_science'
]);

export const educationLevelEnum = pgEnum('education_level', [
  'primary', 'secondary', 'higher_secondary'
]);

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  preferredLanguage: languageEnum("preferred_language").default('hindi'),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Languages table
export const languages = pgTable("languages", {
  id: serial("id").primaryKey(),
  code: languageEnum("code").notNull().unique(),
  name: text("name").notNull(),
  nativeName: text("native_name").notNull(),
  flagUrl: text("flag_url"),
  isActive: boolean("is_active").default(true)
});

// Subject Categories table
export const subjectCategories = pgTable("subject_categories", {
  id: serial("id").primaryKey(),
  code: subjectCategoryEnum("code").notNull().unique(),
  icon: text("icon").notNull(),
  isActive: boolean("is_active").default(true)
});

// Education Levels table
export const educationLevels = pgTable("education_levels", {
  id: serial("id").primaryKey(),
  code: educationLevelEnum("code").notNull().unique(),
  icon: text("icon").notNull(),
  isActive: boolean("is_active").default(true)
});

// Translations table
export const translations = pgTable("translations", {
  id: serial("id").primaryKey(),
  languageId: integer("language_id").references(() => languages.id).notNull(),
  entityType: text("entity_type").notNull(), // 'subject_category', 'education_level', etc.
  entityId: integer("entity_id").notNull(),
  field: text("field").notNull(), // 'name', 'description', etc.
  value: text("value").notNull()
});

// Courses table
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  defaultTitle: text("default_title").notNull(),
  defaultDescription: text("default_description").notNull(),
  imageUrl: text("image_url"),
  durationHours: integer("duration_hours").notNull(),
  subjectCategoryId: integer("subject_category_id").references(() => subjectCategories.id).notNull(),
  educationLevelId: integer("education_level_id").references(() => educationLevels.id).notNull(),
  isPopular: boolean("is_popular").default(false),
  isNew: boolean("is_new").default(false),
  averageRating: integer("average_rating"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  isActive: boolean("is_active").default(true)
});

// Course Chapters table
export const courseChapters = pgTable("course_chapters", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id").references(() => courses.id).notNull(),
  orderIndex: integer("order_index").notNull(),
  defaultTitle: text("default_title").notNull(),
  defaultContent: text("default_content").notNull(),
  isActive: boolean("is_active").default(true)
});

// User Progress table
export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  courseId: integer("course_id").references(() => courses.id).notNull(),
  completedChapters: integer("completed_chapters").default(0),
  lastAccessedAt: timestamp("last_accessed_at").defaultNow().notNull(),
  isCompleted: boolean("is_completed").default(false)
});

// Quiz Questions table
export const quizQuestions = pgTable("quiz_questions", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id").references(() => courses.id).notNull(),
  chapterId: integer("chapter_id").references(() => courseChapters.id),
  defaultQuestion: text("default_question").notNull(),
  options: json("options").notNull(), // array of options with correct flag
  isActive: boolean("is_active").default(true)
});

// Flashcards table
export const flashcards = pgTable("flashcards", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id").references(() => courses.id).notNull(),
  defaultFront: text("default_front").notNull(),
  defaultBack: text("default_back").notNull(),
  isActive: boolean("is_active").default(true)
});

// Interactive Simulations table
export const interactiveSimulations = pgTable("interactive_simulations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  subjectCategoryId: integer("subject_category_id").references(() => subjectCategories.id).notNull(),
  config: json("config").notNull(), // Configuration for the simulation
  isActive: boolean("is_active").default(true)
});

// Relations definitions
export const usersRelations = relations(users, ({ many }) => ({
  progress: many(userProgress)
}));

export const languagesRelations = relations(languages, ({ many }) => ({
  translations: many(translations)
}));

export const subjectCategoriesRelations = relations(subjectCategories, ({ many }) => ({
  courses: many(courses),
  translations: many(translations),
  simulations: many(interactiveSimulations)
}));

export const educationLevelsRelations = relations(educationLevels, ({ many }) => ({
  courses: many(courses),
  translations: many(translations)
}));

export const coursesRelations = relations(courses, ({ many, one }) => ({
  chapters: many(courseChapters),
  userProgress: many(userProgress),
  quizQuestions: many(quizQuestions),
  flashcards: many(flashcards),
  subjectCategory: one(subjectCategories, {
    fields: [courses.subjectCategoryId],
    references: [subjectCategories.id]
  }),
  educationLevel: one(educationLevels, {
    fields: [courses.educationLevelId],
    references: [educationLevels.id]
  })
}));

export const courseChaptersRelations = relations(courseChapters, ({ one, many }) => ({
  course: one(courses, {
    fields: [courseChapters.courseId],
    references: [courses.id]
  }),
  quizQuestions: many(quizQuestions)
}));

export const userProgressRelations = relations(userProgress, ({ one }) => ({
  user: one(users, {
    fields: [userProgress.userId],
    references: [users.id]
  }),
  course: one(courses, {
    fields: [userProgress.courseId],
    references: [courses.id]
  })
}));

export const quizQuestionsRelations = relations(quizQuestions, ({ one }) => ({
  course: one(courses, {
    fields: [quizQuestions.courseId],
    references: [courses.id]
  }),
  chapter: one(courseChapters, {
    fields: [quizQuestions.chapterId],
    references: [courseChapters.id]
  })
}));

export const flashcardsRelations = relations(flashcards, ({ one }) => ({
  course: one(courses, {
    fields: [flashcards.courseId],
    references: [courses.id]
  })
}));

export const interactiveSimulationsRelations = relations(interactiveSimulations, ({ one }) => ({
  subjectCategory: one(subjectCategories, {
    fields: [interactiveSimulations.subjectCategoryId],
    references: [subjectCategories.id]
  })
}));

// Validation schemas
export const insertUserSchema = createInsertSchema(users);
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const insertLanguageSchema = createInsertSchema(languages);
export type InsertLanguage = z.infer<typeof insertLanguageSchema>;
export type Language = typeof languages.$inferSelect;

export const insertSubjectCategorySchema = createInsertSchema(subjectCategories);
export type InsertSubjectCategory = z.infer<typeof insertSubjectCategorySchema>;
export type SubjectCategory = typeof subjectCategories.$inferSelect;

export const insertEducationLevelSchema = createInsertSchema(educationLevels);
export type InsertEducationLevel = z.infer<typeof insertEducationLevelSchema>;
export type EducationLevel = typeof educationLevels.$inferSelect;

export const insertTranslationSchema = createInsertSchema(translations);
export type InsertTranslation = z.infer<typeof insertTranslationSchema>;
export type Translation = typeof translations.$inferSelect;

export const insertCourseSchema = createInsertSchema(courses);
export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = typeof courses.$inferSelect;

export const insertCourseChapterSchema = createInsertSchema(courseChapters);
export type InsertCourseChapter = z.infer<typeof insertCourseChapterSchema>;
export type CourseChapter = typeof courseChapters.$inferSelect;

export const insertUserProgressSchema = createInsertSchema(userProgress);
export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;
export type UserProgress = typeof userProgress.$inferSelect;

export const insertQuizQuestionSchema = createInsertSchema(quizQuestions);
export type InsertQuizQuestion = z.infer<typeof insertQuizQuestionSchema>;
export type QuizQuestion = typeof quizQuestions.$inferSelect;

export const insertFlashcardSchema = createInsertSchema(flashcards);
export type InsertFlashcard = z.infer<typeof insertFlashcardSchema>;
export type Flashcard = typeof flashcards.$inferSelect;

export const insertInteractiveSimulationSchema = createInsertSchema(interactiveSimulations);
export type InsertInteractiveSimulation = z.infer<typeof insertInteractiveSimulationSchema>;
export type InteractiveSimulation = typeof interactiveSimulations.$inferSelect;

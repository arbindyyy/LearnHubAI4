import { db } from "./index";
import * as schema from "@shared/schema";
import { eq } from "drizzle-orm";

async function seed() {
  try {
    console.log("Starting database seeding...");

    // Seed languages
    const languagesData = [
      { code: "hindi" as const, name: "Hindi", nativeName: "हिंदी", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "english" as const, name: "English", nativeName: "English", flagUrl: "https://upload.wikimedia.org/wikipedia/en/a/a4/Flag_of_the_United_Kingdom.svg" },
      { code: "marathi" as const, name: "Marathi", nativeName: "मराठी", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "bengali" as const, name: "Bengali", nativeName: "বাংলা", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "tamil" as const, name: "Tamil", nativeName: "தமிழ்", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "telugu" as const, name: "Telugu", nativeName: "తెలుగు", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "punjabi" as const, name: "Punjabi", nativeName: "ਪੰਜਾਬੀ", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "gujarati" as const, name: "Gujarati", nativeName: "ગુજરાતી", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "kannada" as const, name: "Kannada", nativeName: "ಕನ್ನಡ", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "odia" as const, name: "Odia", nativeName: "ଓଡ଼ିଆ", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "malayalam" as const, name: "Malayalam", nativeName: "മലയാളം", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "assamese" as const, name: "Assamese", nativeName: "অসমীয়া", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "urdu" as const, name: "Urdu", nativeName: "اردو", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "nepali" as const, name: "Nepali", nativeName: "नेपाली", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "konkani" as const, name: "Konkani", nativeName: "कोंकणी", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "manipuri" as const, name: "Manipuri", nativeName: "মৈতৈলোন্", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "sanskrit" as const, name: "Sanskrit", nativeName: "संस्कृतम्", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "sindhi" as const, name: "Sindhi", nativeName: "سنڌي", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "bodo" as const, name: "Bodo", nativeName: "बड़ो", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "dogri" as const, name: "Dogri", nativeName: "डोगरी", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
      { code: "kashmiri" as const, name: "Kashmiri", nativeName: "कॉशुर", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" }
    ];

    console.log("Seeding languages...");
    for (const language of languagesData) {
      const existingLanguage = await db.query.languages.findFirst({
        where: eq(schema.languages.code, language.code)
      });

      if (!existingLanguage) {
        await db.insert(schema.languages).values(language);
        console.log(`Added language: ${language.name}`);
      } else {
        console.log(`Language ${language.name} already exists.`);
      }
    }

    // Seed subject categories
    const subjectCategoriesData = [
      { code: "mathematics" as const, icon: "functions" },
      { code: "science" as const, icon: "science" },
      { code: "history" as const, icon: "history_edu" },
      { code: "language" as const, icon: "menu_book" },
      { code: "geography" as const, icon: "public" },
      { code: "computer_science" as const, icon: "computer" }
    ];

    console.log("Seeding subject categories...");
    for (const category of subjectCategoriesData) {
      const existingCategory = await db.query.subjectCategories.findFirst({
        where: eq(schema.subjectCategories.code, category.code)
      });

      if (!existingCategory) {
        await db.insert(schema.subjectCategories).values(category);
        console.log(`Added subject category: ${category.code}`);
      } else {
        console.log(`Subject category ${category.code} already exists.`);
      }
    }

    // Seed education levels
    const educationLevelsData = [
      { code: "primary" as const, icon: "child_care" },
      { code: "secondary" as const, icon: "school" },
      { code: "higher_secondary" as const, icon: "account_balance" }
    ];

    console.log("Seeding education levels...");
    for (const level of educationLevelsData) {
      const existingLevel = await db.query.educationLevels.findFirst({
        where: eq(schema.educationLevels.code, level.code)
      });

      if (!existingLevel) {
        await db.insert(schema.educationLevels).values(level);
        console.log(`Added education level: ${level.code}`);
      } else {
        console.log(`Education level ${level.code} already exists.`);
      }
    }

    // Get all inserted categories and levels for reference
    const categories = await db.query.subjectCategories.findMany();
    const levels = await db.query.educationLevels.findMany();
    const hindi = await db.query.languages.findFirst({
      where: eq(schema.languages.code, "hindi")
    });

    // Seed translations for categories (Hindi)
    if (hindi) {
      console.log("Seeding translations for subject categories...");
      const categoryTranslations = [
        { code: "mathematics", name: "गणित" },
        { code: "science", name: "विज्ञान" },
        { code: "history", name: "इतिहास" },
        { code: "language", name: "भाषा" },
        { code: "geography", name: "भूगोल" },
        { code: "computer_science", name: "कंप्यूटर विज्ञान" }
      ];

      for (const trans of categoryTranslations) {
        const category = categories.find(c => c.code === trans.code);
        if (category) {
          const existingTranslation = await db.query.translations.findFirst({
            where: (t) => {
              return eq(t.languageId, hindi.id) && 
                     eq(t.entityType, "subject_category") && 
                     eq(t.entityId, category.id) &&
                     eq(t.field, "name");
            }
          });

          if (!existingTranslation) {
            await db.insert(schema.translations).values({
              languageId: hindi.id,
              entityType: "subject_category",
              entityId: category.id,
              field: "name",
              value: trans.name
            });
            console.log(`Added translation for ${trans.code}`);
          } else {
            console.log(`Translation for ${trans.code} already exists.`);
          }
        }
      }
    }

    // Seed translations for education levels (Hindi)
    if (hindi) {
      console.log("Seeding translations for education levels...");
      const levelTranslations = [
        { code: "primary", name: "प्राथमिक (कक्षा 1-5)" },
        { code: "secondary", name: "माध्यमिक (कक्षा 6-10)" },
        { code: "higher_secondary", name: "उच्च माध्यमिक (कक्षा 11-12)" }
      ];

      for (const trans of levelTranslations) {
        const level = levels.find(l => l.code === trans.code);
        if (level) {
          const existingTranslation = await db.query.translations.findFirst({
            where: (t) => {
              return eq(t.languageId, hindi.id) && 
                     eq(t.entityType, "education_level") && 
                     eq(t.entityId, level.id) &&
                     eq(t.field, "name");
            }
          });

          if (!existingTranslation) {
            await db.insert(schema.translations).values({
              languageId: hindi.id,
              entityType: "education_level",
              entityId: level.id,
              field: "name",
              value: trans.name
            });
            console.log(`Added translation for ${trans.code}`);
          } else {
            console.log(`Translation for ${trans.code} already exists.`);
          }
        }
      }
    }

    // Seed courses
    const mathCategory = categories.find(c => c.code === "mathematics");
    const scienceCategory = categories.find(c => c.code === "science");
    const historyCategory = categories.find(c => c.code === "history");
    const languageCategory = categories.find(c => c.code === "language");
    const secondaryLevel = levels.find(l => l.code === "secondary");

    if (mathCategory && scienceCategory && historyCategory && languageCategory && secondaryLevel && hindi) {
      console.log("Seeding courses...");
      
      const coursesData = [
        {
          slug: "modern-algebra",
          defaultTitle: "Modern Algebra",
          defaultDescription: "Learn the fundamental concepts of algebra and how to solve equations",
          imageUrl: "https://images.unsplash.com/photo-1635372722656-389f87a941b7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
          durationHours: 8,
          subjectCategoryId: mathCategory.id,
          educationLevelId: secondaryLevel.id,
          isPopular: true,
          averageRating: 42 // 4.2 * 10
        },
        {
          slug: "modern-physics",
          defaultTitle: "Modern Physics",
          defaultDescription: "From Newton's laws to modern physics, a comprehensive course",
          imageUrl: "https://images.unsplash.com/photo-1581093450021-4a7360e9a6b5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
          durationHours: 10,
          subjectCategoryId: scienceCategory.id,
          educationLevelId: secondaryLevel.id,
          isPopular: false,
          averageRating: 48 // 4.8 * 10
        },
        {
          slug: "indian-freedom-struggle",
          defaultTitle: "Indian Freedom Struggle",
          defaultDescription: "A detailed study of the Indian freedom struggle and key events",
          imageUrl: "https://images.unsplash.com/photo-1535905557558-afc4877a26fc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
          durationHours: 12,
          subjectCategoryId: historyCategory.id,
          educationLevelId: secondaryLevel.id,
          isPopular: false,
          averageRating: 45 // 4.5 * 10
        },
        {
          slug: "hindi-grammar-expert",
          defaultTitle: "Hindi Grammar Expert",
          defaultDescription: "Understand the rules of Hindi grammar and improve your language skills",
          imageUrl: "https://images.unsplash.com/photo-1457369804613-52c61a468e7d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
          durationHours: 15,
          subjectCategoryId: languageCategory.id,
          educationLevelId: secondaryLevel.id,
          isNew: true,
          averageRating: 43 // 4.3 * 10
        }
      ];

      for (const course of coursesData) {
        const existingCourse = await db.query.courses.findFirst({
          where: eq(schema.courses.slug, course.slug)
        });

        if (!existingCourse) {
          const [newCourse] = await db.insert(schema.courses).values(course).returning();
          console.log(`Added course: ${course.defaultTitle}`);

          // Add Hindi translations for course titles and descriptions
          await db.insert(schema.translations).values({
            languageId: hindi.id,
            entityType: "course",
            entityId: newCourse.id,
            field: "title",
            value: course.slug === "modern-algebra" ? "आधुनिक बीजगणित" : 
                  course.slug === "modern-physics" ? "आधुनिक भौतिकी" :
                  course.slug === "indian-freedom-struggle" ? "भारतीय स्वतंत्रता संग्राम" :
                  "हिंदी व्याकरण विशेषज्ञ"
          });

          await db.insert(schema.translations).values({
            languageId: hindi.id,
            entityType: "course",
            entityId: newCourse.id,
            field: "description",
            value: course.slug === "modern-algebra" ? "बीजगणित की मूलभूत अवधारणाओं को समझें और समीकरणों को हल करना सीखें" : 
                  course.slug === "modern-physics" ? "न्यूटन के नियमों से लेकर आधुनिक भौतिकी तक, एक व्यापक पाठ्यक्रम" :
                  course.slug === "indian-freedom-struggle" ? "भारतीय स्वतंत्रता संग्राम का विस्तृत अध्ययन और महत्वपूर्ण घटनाएँ" :
                  "हिंदी व्याकरण के नियमों को समझें और अपनी भाषा कौशल में सुधार करें"
          });

          // Add chapters for Algebra course
          if (course.slug === "modern-algebra") {
            const chapters = [
              { courseId: newCourse.id, orderIndex: 1, defaultTitle: "Introduction to Algebra", defaultContent: "Basic introduction to algebra concepts" },
              { courseId: newCourse.id, orderIndex: 2, defaultTitle: "Linear Equations", defaultContent: "Solving linear equations with one variable" },
              { courseId: newCourse.id, orderIndex: 3, defaultTitle: "Quadratic Equations", defaultContent: "Understanding and solving quadratic equations" },
              { courseId: newCourse.id, orderIndex: 4, defaultTitle: "Polynomials", defaultContent: "Working with polynomial expressions" },
              { courseId: newCourse.id, orderIndex: 5, defaultTitle: "Factorization", defaultContent: "Methods of factorizing algebraic expressions" },
              { courseId: newCourse.id, orderIndex: 6, defaultTitle: "Algebraic Fractions", defaultContent: "Operations with algebraic fractions" },
              { courseId: newCourse.id, orderIndex: 7, defaultTitle: "Exponents and Powers", defaultContent: "Understanding exponents and powers in algebra" },
              { courseId: newCourse.id, orderIndex: 8, defaultTitle: "Roots and Radicals", defaultContent: "Working with roots and radical expressions" },
              { courseId: newCourse.id, orderIndex: 9, defaultTitle: "Functions", defaultContent: "Introduction to algebraic functions" },
              { courseId: newCourse.id, orderIndex: 10, defaultTitle: "Graphs", defaultContent: "Graphing algebraic functions" },
              { courseId: newCourse.id, orderIndex: 11, defaultTitle: "Sequences and Series", defaultContent: "Understanding arithmetic and geometric sequences" },
              { courseId: newCourse.id, orderIndex: 12, defaultTitle: "Algebraic Applications", defaultContent: "Real-world applications of algebra" }
            ];

            for (const chapter of chapters) {
              await db.insert(schema.courseChapters).values(chapter);
            }

            // Add sample quiz question
            await db.insert(schema.quizQuestions).values({
              courseId: newCourse.id,
              defaultQuestion: "If x + y = 10 and xy = 21, what is the value of x² + y²?",
              options: JSON.stringify([
                { text: "58", isCorrect: true },
                { text: "100", isCorrect: false },
                { text: "58", isCorrect: false },
                { text: "42", isCorrect: false }
              ])
            });
          }
        } else {
          console.log(`Course ${course.defaultTitle} already exists.`);
        }
      }
    }

    // Seed interactive simulations
    if (mathCategory && scienceCategory) {
      console.log("Seeding interactive simulations...");
      
      const simulationsData = [
        {
          name: "Quadratic Equation Solver",
          description: "Visualize how changing coefficients affects the graph of a quadratic equation",
          subjectCategoryId: mathCategory.id,
          config: JSON.stringify({ type: "equation-solver", complexity: "medium" })
        },
        {
          name: "Virtual Physics Lab",
          description: "Experiment with forces, motion, and energy in a virtual laboratory",
          subjectCategoryId: scienceCategory.id,
          config: JSON.stringify({ type: "physics-simulation", complexity: "advanced" })
        }
      ];

      for (const simulation of simulationsData) {
        const existingSimulation = await db.query.interactiveSimulations.findFirst({
          where: eq(schema.interactiveSimulations.name, simulation.name)
        });

        if (!existingSimulation) {
          await db.insert(schema.interactiveSimulations).values(simulation);
          console.log(`Added simulation: ${simulation.name}`);
        } else {
          console.log(`Simulation ${simulation.name} already exists.`);
        }
      }
    }

    // Seed a sample flashcard set
    const algebraCourse = await db.query.courses.findFirst({
      where: eq(schema.courses.slug, "modern-algebra")
    });

    if (algebraCourse) {
      console.log("Seeding flashcards...");
      
      const flashcardsData = [
        {
          courseId: algebraCourse.id, 
          defaultFront: "What is a quadratic equation?", 
          defaultBack: "An equation of the form ax² + bx + c = 0, where a ≠ 0."
        },
        {
          courseId: algebraCourse.id, 
          defaultFront: "What is the quadratic formula?", 
          defaultBack: "x = (-b ± √(b² - 4ac)) / 2a"
        },
        {
          courseId: algebraCourse.id, 
          defaultFront: "What is a polynomial?", 
          defaultBack: "An expression consisting of variables and coefficients using only addition, subtraction, multiplication, and non-negative integer exponents."
        }
      ];

      for (const flashcard of flashcardsData) {
        const existingFlashcard = await db.query.flashcards.findFirst({
          where: (f) => {
            return eq(f.courseId, flashcard.courseId) && 
                   eq(f.defaultFront, flashcard.defaultFront);
          }
        });

        if (!existingFlashcard) {
          await db.insert(schema.flashcards).values(flashcard);
          console.log(`Added flashcard: ${flashcard.defaultFront}`);
        } else {
          console.log(`Flashcard already exists.`);
        }
      }
    }

    console.log("Database seeding completed successfully!");
  } catch (error) {
    console.error("Error during database seeding:", error);
  }
}

seed();

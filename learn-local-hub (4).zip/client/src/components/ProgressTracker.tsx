import { Link } from "wouter";
import { Progress } from "@/components/ui/progress";
import { useLanguage } from "@/hooks/use-language";
import { useQuery } from "@tanstack/react-query";
import { CourseProgress } from "@/lib/types";

interface ProgressTrackerProps {
  courseId?: number;
  className?: string;
}

const ProgressTracker = ({ courseId, className }: ProgressTrackerProps) => {
  const { t } = useLanguage();
  
  const { data, isLoading } = useQuery({
    queryKey: [`/api/user-progress${courseId ? `?courseId=${courseId}` : ''}`],
  });

  if (isLoading) {
    return (
      <div className={`bg-white p-5 rounded-lg shadow-md ${className}`}>
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-3/4 mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-6"></div>
          <div className="h-2 bg-gray-200 rounded mb-6"></div>
          <div className="flex gap-3">
            <div className="h-10 bg-gray-200 rounded flex-1"></div>
            <div className="h-10 bg-gray-200 rounded flex-1"></div>
            <div className="h-10 bg-gray-200 rounded flex-1"></div>
          </div>
        </div>
      </div>
    );
  }

  // If no progress data is available yet
  if (!data || !data.progress) {
    return (
      <div className={`bg-white p-5 rounded-lg shadow-md ${className}`}>
        <div className="text-center py-4">
          <h3 className="font-medium text-lg mb-2">{t('progress.noData')}</h3>
          <p className="text-neutral-500 text-sm mb-4">{t('progress.startCourse')}</p>
          <Link href="/courses" className="px-4 py-2 bg-primary text-white text-center rounded-lg text-sm hover:bg-primary-dark transition-colors">
            {t('progress.browseCourses')}
          </Link>
        </div>
      </div>
    );
  }

  const progress: CourseProgress = data.progress;
  const course = progress.course || {
    title: t('progress.currentCourse'),
    slug: '',
    completedChapters: progress.completedChapters || 0,
    totalChapters: 12 // Fallback if no course data
  };
  
  const completedChapters = progress.completedChapters || 0;
  const totalChapters = course.totalChapters || 12;
  const percentComplete = Math.round((completedChapters / totalChapters) * 100);

  return (
    <div className={`bg-white p-5 rounded-lg shadow-md ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-medium text-lg">{course.title}</h3>
          <p className="text-neutral-500 text-sm">
            {t('progress.chaptersComplete', { 
              completed: completedChapters, 
              total: totalChapters 
            })}
          </p>
        </div>
        <span className="text-xl font-semibold text-primary">{percentComplete}%</span>
      </div>
      
      <Progress value={percentComplete} className="h-2.5 mb-4" />
      
      <div className="grid grid-cols-3 gap-3">
        <Link href={`/courses/${course.slug}${completedChapters > 0 ? `/chapters/${completedChapters + 1}` : ''}`} 
              className="px-3 py-2 bg-primary text-white text-center rounded-lg text-sm hover:bg-primary-dark transition-colors">
          {t('progress.nextChapter')}
        </Link>
        <Link href={`/courses/${course.slug}/practice`} 
              className="px-3 py-2 border border-neutral-300 text-neutral-700 text-center rounded-lg text-sm hover:bg-neutral-50 transition-colors">
          {t('progress.lastPractice')}
        </Link>
        <Link href="/progress" 
              className="px-3 py-2 border border-neutral-300 text-neutral-700 text-center rounded-lg text-sm hover:bg-neutral-50 transition-colors">
          {t('progress.yourProgress')}
        </Link>
      </div>
    </div>
  );
};

export default ProgressTracker;

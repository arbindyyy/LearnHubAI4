import { useState, useRef, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { useLanguage } from "@/hooks/use-language";
import { languages } from "@/lib/constants";
import { useMobile } from "@/hooks/use-mobile";
import { Book, School, User } from "lucide-react";

const Header = () => {
  const [isLangDropdownOpen, setLangDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const { currentLanguage, setLanguage, t } = useLanguage();
  const [location] = useLocation();
  const isMobile = useMobile();

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setLangDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const toggleLangDropdown = () => {
    setLangDropdownOpen(!isLangDropdownOpen);
  };

  const handleLanguageChange = (langCode: string) => {
    setLanguage(langCode);
    setLangDropdownOpen(false);
  };

  return (
    <header className="bg-white shadow-md fixed top-0 left-0 right-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <School className="h-6 w-6 text-primary mr-2" />
              <h1 className="font-heading font-bold text-xl sm:text-2xl text-primary">
                LearnLocalHub
              </h1>
            </Link>
          </div>

          {/* Desktop Nav */}
          {!isMobile && (
            <nav className="hidden md:flex items-center space-x-6">
              <Link href="/" className={`font-medium ${location === '/' ? 'text-primary' : 'text-neutral-700 hover:text-primary'} transition-colors`}>
                {t('nav.home')}
              </Link>
              <Link href="/courses" className={`font-medium ${location.startsWith('/courses') ? 'text-primary' : 'text-neutral-700 hover:text-primary'} transition-colors`}>
                {t('nav.courses')}
              </Link>
              <Link href="/practice" className={`font-medium ${location.startsWith('/practice') ? 'text-primary' : 'text-neutral-700 hover:text-primary'} transition-colors`}>
                {t('nav.practice')}
              </Link>
              <Link href="/progress" className={`font-medium ${location.startsWith('/progress') ? 'text-primary' : 'text-neutral-700 hover:text-primary'} transition-colors`}>
                {t('nav.progress')}
              </Link>
              <Link href="/help" className={`font-medium ${location.startsWith('/help') ? 'text-primary' : 'text-neutral-700 hover:text-primary'} transition-colors`}>
                {t('nav.help')}
              </Link>
            </nav>
          )}

          {/* User Actions */}
          <div className="flex items-center space-x-4">
            {/* Language Dropdown */}
            <div className="relative" ref={dropdownRef}>
              <button 
                className="flex items-center px-3 py-1 border border-neutral-200 rounded-md text-sm hover:bg-neutral-100"
                onClick={toggleLangDropdown}
              >
                <img 
                  src={languages.find(lang => lang.code === currentLanguage)?.flagUrl} 
                  alt={currentLanguage} 
                  className="w-4 h-4 mr-2" 
                />
                <span>{languages.find(lang => lang.code === currentLanguage)?.nativeName}</span>
                <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              
              {isLangDropdownOpen && (
                <div className="absolute right-0 mt-1 bg-white border border-neutral-200 rounded-md shadow-lg w-48 z-10 max-h-96 overflow-y-auto">
                  <div className="p-2 text-xs text-neutral-500 border-b border-neutral-200">
                    {t('languages.available', { count: languages.length })}
                  </div>
                  
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      className="block w-full text-left px-4 py-2 hover:bg-neutral-100 text-sm"
                      onClick={() => handleLanguageChange(lang.code)}
                    >
                      <div className="flex items-center">
                        <img 
                          src={lang.flagUrl} 
                          alt={lang.name} 
                          className="w-4 h-4 mr-2" 
                        />
                        <span>{lang.nativeName}</span>
                      </div>
                    </button>
                  ))}
                  
                  <div className="p-2 text-center border-t border-neutral-200">
                    <Link href="/languages" className="text-xs text-primary hover:underline">
                      {t('languages.viewAll')}
                    </Link>
                  </div>
                </div>
              )}
            </div>

            {/* Profile Button */}
            <button className="flex items-center justify-center p-2 rounded-full hover:bg-neutral-100">
              <User className="h-5 w-5 text-neutral-600" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;

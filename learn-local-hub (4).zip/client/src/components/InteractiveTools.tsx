import { Link } from "wouter";
import { BoltIcon, Brain, Beaker, Edit3 } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";
import { useQuery } from "@tanstack/react-query";

const InteractiveTools = () => {
  const { t, languageId } = useLanguage();
  
  const { data: simulationsData } = useQuery({
    queryKey: [`/api/interactive-simulations?languageId=${languageId}`],
  });

  const simulations = simulationsData?.simulations || [];

  const toolsData = [
    {
      icon: <BoltIcon className="text-2xl text-primary" />,
      title: t('tools.quiz.title'),
      description: t('tools.quiz.description'),
      link: "/quiz",
      linkText: t('tools.quiz.action'),
      bgColor: "bg-primary bg-opacity-10",
      textColor: "text-primary",
      IconComponent: BoltIcon
    },
    {
      icon: <Brain className="text-2xl text-secondary" />,
      title: t('tools.flashcards.title'),
      description: t('tools.flashcards.description'),
      link: "/flashcards",
      linkText: t('tools.flashcards.action'),
      bgColor: "bg-secondary bg-opacity-10",
      textColor: "text-secondary",
      IconComponent: Brain
    },
    {
      icon: <Beaker className="text-2xl text-accent" />,
      title: t('tools.simulations.title'),
      description: t('tools.simulations.description'),
      link: "/simulations",
      linkText: t('tools.simulations.action'),
      bgColor: "bg-accent bg-opacity-10",
      textColor: "text-accent",
      IconComponent: Beaker
    },
    {
      icon: <Edit3 className="text-2xl text-primary-dark" />,
      title: t('tools.practice.title'),
      description: t('tools.practice.description'),
      link: "/practice",
      linkText: t('tools.practice.action'),
      bgColor: "bg-primary-dark bg-opacity-10",
      textColor: "text-primary-dark",
      IconComponent: Edit3
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {toolsData.map((tool, index) => (
        <div key={index} className="bg-white border border-neutral-200 rounded-xl p-5 hover:shadow-md transition-shadow">
          <div className="flex items-start">
            <div className={`p-3 ${tool.bgColor} rounded-full mr-4`}>
              <tool.IconComponent className={`h-6 w-6 ${tool.textColor}`} />
            </div>
            <div className="flex-1">
              <h3 className="font-heading font-semibold text-lg mb-1">{tool.title}</h3>
              <p className="text-neutral-600 text-sm mb-3">
                {tool.description}
              </p>
              <Link href={tool.link} className={`inline-flex items-center ${tool.textColor} text-sm font-medium hover:underline`}>
                {tool.linkText}
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </Link>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default InteractiveTools;

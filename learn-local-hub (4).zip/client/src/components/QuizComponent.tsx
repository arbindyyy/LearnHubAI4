import { useState } from "react";
import { useLanguage } from "@/hooks/use-language";
import { cn } from "@/lib/utils";
import { QuizQuestion } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface QuizComponentProps {
  questions: QuizQuestion[];
  onComplete?: (score: number, totalQuestions: number) => void;
}

const QuizComponent = ({ questions = [], onComplete }: QuizComponentProps) => {
  const { t } = useLanguage();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const currentQuestion = questions[currentQuestionIndex];

  const handleAnswerSelection = (optionIndex: number) => {
    if (isSubmitted) return;
    
    setSelectedAnswers({
      ...selectedAnswers,
      [currentQuestionIndex]: optionIndex
    });
  };

  const goToPreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const goToNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const goToQuestion = (index: number) => {
    if (index >= 0 && index < questions.length) {
      setCurrentQuestionIndex(index);
    }
  };

  const submitQuiz = () => {
    setIsSubmitted(true);
    
    // Calculate score
    let correctAnswers = 0;
    Object.keys(selectedAnswers).forEach((questionIndex) => {
      const qIndex = parseInt(questionIndex);
      const aIndex = selectedAnswers[qIndex];
      const options = questions[qIndex]?.options || [];
      
      if (options[aIndex]?.isCorrect) {
        correctAnswers++;
      }
    });
    
    if (onComplete) {
      onComplete(correctAnswers, questions.length);
    }
  };

  if (!currentQuestion) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-center text-neutral-500">{t('quiz.noQuestions')}</p>
        </CardContent>
      </Card>
    );
  }

  const isOptionSelected = (questionIndex: number) => {
    return selectedAnswers[questionIndex] !== undefined;
  };

  const isAnswerCorrect = (questionIndex: number, optionIndex: number) => {
    if (!isSubmitted) return false;
    return questions[questionIndex]?.options[optionIndex]?.isCorrect;
  };

  const getOptionClassName = (questionIndex: number, optionIndex: number) => {
    const isSelected = selectedAnswers[questionIndex] === optionIndex;
    const isCorrect = isAnswerCorrect(questionIndex, optionIndex);
    
    if (!isSubmitted) {
      return cn(
        "flex items-center p-3 border rounded-lg cursor-pointer hover:bg-neutral-50",
        isSelected ? "border-primary bg-primary bg-opacity-5" : "border-neutral-300"
      );
    }
    
    if (isCorrect) {
      return "flex items-center p-3 border border-green-500 bg-green-50 rounded-lg";
    }
    
    if (isSelected && !isCorrect) {
      return "flex items-center p-3 border border-red-500 bg-red-50 rounded-lg";
    }
    
    return "flex items-center p-3 border border-neutral-300 rounded-lg";
  };

  return (
    <Card className="bg-white rounded-xl shadow-md">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-neutral-800">{t('quiz.title')}</CardTitle>
      </CardHeader>
      
      <CardContent>
        <div className="bg-neutral-100 rounded-lg p-5">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-medium">{currentQuestion.category}</h3>
            <div className="text-sm text-neutral-500">
              {t('quiz.questionCount', { current: currentQuestionIndex + 1, total: questions.length })}
            </div>
          </div>
          
          <div className="mb-5">
            <p className="text-lg font-medium mb-3">{currentQuestion.question}</p>
            
            <div className="space-y-3">
              {currentQuestion.options.map((option, index) => (
                <label
                  key={index}
                  className={getOptionClassName(currentQuestionIndex, index)}
                  onClick={() => handleAnswerSelection(index)}
                >
                  <input
                    type="radio"
                    name={`question${currentQuestionIndex}`}
                    className="mr-3"
                    checked={selectedAnswers[currentQuestionIndex] === index}
                    onChange={() => {}}
                  />
                  <span>{option.text}</span>
                </label>
              ))}
            </div>
            
            {isSubmitted && selectedAnswers[currentQuestionIndex] !== undefined && (
              <div className="mt-3 p-3 rounded-lg bg-neutral-100">
                <p className="font-medium">
                  {isAnswerCorrect(currentQuestionIndex, selectedAnswers[currentQuestionIndex]) 
                    ? t('quiz.correctAnswer') 
                    : t('quiz.incorrectAnswer')}
                </p>
                <p className="text-sm text-neutral-600 mt-1">
                  {isAnswerCorrect(currentQuestionIndex, selectedAnswers[currentQuestionIndex])
                    ? t('quiz.goodJob')
                    : t('quiz.correctWas', { 
                        answer: currentQuestion.options.find(opt => opt.isCorrect)?.text || '' 
                      })}
                </p>
              </div>
            )}
          </div>
          
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={goToPreviousQuestion}
              disabled={currentQuestionIndex === 0}
            >
              {t('quiz.previous')}
            </Button>
            
            <div className="flex gap-1">
              {questions.map((_, index) => (
                <button
                  key={index}
                  className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center",
                    currentQuestionIndex === index 
                      ? "bg-primary text-white" 
                      : isOptionSelected(index)
                        ? "border border-primary text-primary"
                        : "border border-neutral-300"
                  )}
                  onClick={() => goToQuestion(index)}
                >
                  {index + 1}
                </button>
              ))}
            </div>
            
            {currentQuestionIndex < questions.length - 1 ? (
              <Button onClick={goToNextQuestion}>
                {t('quiz.next')}
              </Button>
            ) : (
              <Button 
                onClick={submitQuiz} 
                disabled={isSubmitted || Object.keys(selectedAnswers).length < questions.length}
              >
                {t('quiz.submit')}
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default QuizComponent;

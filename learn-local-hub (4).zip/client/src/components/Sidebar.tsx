import { Link, useLocation } from "wouter";
import { useLanguage } from "@/hooks/use-language";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { 
  Parentheses, 
  Biohazard, 
  University, 
  SquareMenu, 
  SunMedium, 
  Computer,
  Baby,
  School,
  Wallet
} from "lucide-react";

const iconMap: Record<string, React.ReactNode> = {
  functions: <Parentheses className="w-5 h-5 mr-3" />,
  science: <Biohazard className="w-5 h-5 mr-3" />,
  history_edu: <University className="w-5 h-5 mr-3" />,
  menu_book: <SquareMenu className="w-5 h-5 mr-3" />,
  public: <SunMedium className="w-5 h-5 mr-3" />,
  computer: <Computer className="w-5 h-5 mr-3" />,
  child_care: <Baby className="w-5 h-5 mr-3" />,
  school: <School className="w-5 h-5 mr-3" />,
  account_balance: <Wallet className="w-5 h-5 mr-3" />
};

const Sidebar = () => {
  const [location] = useLocation();
  const { languageId, t } = useLanguage();

  const { data: subjectData } = useQuery({
    queryKey: [`/api/subjects?languageId=${languageId}`],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const { data: levelData } = useQuery({
    queryKey: [`/api/education-levels?languageId=${languageId}`],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const subjects = subjectData?.subjects || [];
  const levels = levelData?.levels || [];

  return (
    <aside className="w-64 bg-white shadow-md fixed left-0 bottom-0 top-16 overflow-y-auto">
      <div className="p-4">
        <h2 className="font-heading font-semibold text-lg text-neutral-800 mb-4">
          {t('sidebar.categories')}
        </h2>
        
        {/* Subject categories */}
        <ul className="space-y-1">
          {subjects.map((subject) => (
            <li key={subject.id}>
              <Link href={`/subjects/${subject.code}`}>
                {({ isActive }) => (
                  <div className={cn(
                    "flex items-center p-3 rounded-lg",
                    isActive || location === `/subjects/${subject.code}` 
                      ? "bg-primary bg-opacity-10 text-primary"
                      : "hover:bg-neutral-100 text-neutral-700"
                  )}>
                    {iconMap[subject.icon] || <div className="w-5 h-5 mr-3" />}
                    <span>{subject.name}</span>
                  </div>
                )}
              </Link>
            </li>
          ))}
        </ul>

        <h2 className="font-heading font-semibold text-lg text-neutral-800 mt-8 mb-4">
          {t('sidebar.educationLevels')}
        </h2>
        
        {/* Education levels */}
        <ul className="space-y-1">
          {levels.map((level) => (
            <li key={level.id}>
              <Link href={`/levels/${level.code}`}>
                {({ isActive }) => (
                  <div className={cn(
                    "flex items-center p-3 rounded-lg",
                    isActive || location === `/levels/${level.code}` 
                      ? "bg-primary bg-opacity-10 text-primary"
                      : "hover:bg-neutral-100 text-neutral-700"
                  )}>
                    {iconMap[level.icon] || <div className="w-5 h-5 mr-3" />}
                    <span>{level.name}</span>
                  </div>
                )}
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </aside>
  );
};

export default Sidebar;

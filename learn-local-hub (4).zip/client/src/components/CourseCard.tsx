import { Link } from "wouter";
import { Star, StarHalf } from "lucide-react";
import { Course } from "@/lib/types";
import { cn } from "@/lib/utils";
import { useLanguage } from "@/hooks/use-language";

interface CourseCardProps {
  course: Course;
}

const CourseCard = ({ course }: CourseCardProps) => {
  const { t } = useLanguage();

  // Create a star rating display
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating - fullStars >= 0.5;
    
    // Add full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`star-${i}`} className="text-secondary" fill="currentColor" />);
    }
    
    // Add half star if needed
    if (hasHalfStar) {
      stars.push(<StarHalf key="half-star" className="text-secondary" fill="currentColor" />);
    }
    
    // Add empty stars
    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-neutral-300" />);
    }
    
    return stars;
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="h-40 bg-secondary-light relative">
        {course.imageUrl ? (
          <img 
            src={course.imageUrl} 
            alt={course.title} 
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-primary-light flex items-center justify-center text-white">
            <span className="text-xl font-semibold">{course.title.charAt(0)}</span>
          </div>
        )}
        
        {course.isPopular && (
          <div className="absolute top-3 right-3 bg-primary text-white text-xs px-2 py-1 rounded">
            {t('course.popular')}
          </div>
        )}
        
        {course.isNew && (
          <div className="absolute top-3 right-3 bg-primary text-white text-xs px-2 py-1 rounded">
            {t('course.new')}
          </div>
        )}
      </div>
      
      <div className="p-4">
        <div className="flex items-center text-sm text-neutral-500 mb-2">
          <span className="mr-1">{course.category?.icon && (
            <span className={cn("w-4 h-4 inline-block mr-1")}></span>
          )}</span>
          <span>{course.category?.name}</span>
          <span className="mx-2">•</span>
          <span className="mr-1">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 inline" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </span>
          <span>{course.durationHours} {t('course.hours')}</span>
        </div>
        
        <h3 className="font-heading font-semibold text-lg mb-2">{course.title}</h3>
        <p className="text-sm text-neutral-600 mb-4 line-clamp-2">{course.description}</p>
        
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <div className="flex">
              {course.rating ? renderStars(course.rating) : null}
            </div>
            {course.rating && <span className="text-sm text-neutral-500 ml-1">{course.rating.toFixed(1)}</span>}
          </div>
          
          <Link href={`/courses/${course.slug}`} className="text-primary text-sm font-medium hover:underline">
            {t('course.startNow')}
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CourseCard;

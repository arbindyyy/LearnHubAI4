import { Link, useLocation } from "wouter";
import { Home, BookOpen, Brain, User } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";
import { cn } from "@/lib/utils";

const MobileNavigation = () => {
  const [location] = useLocation();
  const { t } = useLanguage();

  const navItems = [
    { icon: Home, label: t('nav.home'), path: '/' },
    { icon: BookOpen, label: t('nav.courses'), path: '/courses' },
    { icon: Brain, label: t('nav.practice'), path: '/practice' },
    { icon: User, label: t('nav.profile'), path: '/profile' }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-neutral-200 z-40">
      <div className="flex justify-around">
        {navItems.map((item, index) => {
          const Icon = item.icon;
          const isActive = 
            item.path === '/' ? location === '/' : location.startsWith(item.path);
          
          return (
            <Link key={index} href={item.path}>
              <a className={cn(
                "flex flex-col items-center p-3",
                isActive ? "text-primary" : "text-neutral-500"
              )}>
                <Icon size={20} />
                <span className="text-xs mt-1">{item.label}</span>
              </a>
            </Link>
          );
        })}
      </div>
    </nav>
  );
};

export default MobileNavigation;

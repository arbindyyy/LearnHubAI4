import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import CourseDetail from "@/pages/CourseDetail";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import MobileNavigation from "@/components/MobileNavigation";
import { LanguageProvider } from "@/hooks/use-language";
import { useMobile } from "@/hooks/use-mobile";

function Router() {
  const isMobile = useMobile();

  return (
    <div className="flex pt-16 min-h-screen">
      {!isMobile && <Sidebar />}

      <main className={`flex-1 ${!isMobile ? 'md:ml-64' : ''} p-4 md:p-8`}>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/courses/:slug" component={CourseDetail} />
          <Route component={NotFound} />
        </Switch>
      </main>

      {isMobile && <MobileNavigation />}
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <Header />
        <Router />
        <Toaster />
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;

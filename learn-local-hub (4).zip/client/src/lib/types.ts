// Common types for the application

// Language types
export interface Language {
  id: number;
  code: string;
  name: string;
  nativeName: string;
  flagUrl: string;
  isActive: boolean;
}

// Subject Category types
export interface SubjectCategory {
  id: number;
  code: string;
  name?: string; // Might be populated from translations
  icon: string;
  isActive: boolean;
}

// Education Level types
export interface EducationLevel {
  id: number;
  code: string;
  name?: string; // Might be populated from translations
  icon: string;
  isActive: boolean;
}

// Course types
export interface Course {
  id: number;
  slug: string;
  title: string; // Translated title
  defaultTitle: string;
  description: string; // Translated description
  defaultDescription: string;
  imageUrl?: string;
  durationHours: number;
  subjectCategoryId: number;
  educationLevelId: number;
  category?: SubjectCategory;
  level?: EducationLevel;
  isPopular: boolean;
  isNew: boolean;
  averageRating?: number;
  rating?: number; // Formatted rating (e.g., 4.5)
  createdAt: string;
  isActive: boolean;
  totalChapters?: number;
  chapters?: CourseChapter[];
}

// Course Chapter types
export interface CourseChapter {
  id: number;
  courseId: number;
  orderIndex: number;
  title: string; // Translated title
  defaultTitle: string;
  content: string; // Translated content
  defaultContent: string;
  isActive: boolean;
}

// User Progress types
export interface UserProgress {
  id: number;
  userId: number;
  courseId: number;
  completedChapters: number;
  lastAccessedAt: string;
  isCompleted: boolean;
}

// Course Progress types (with related course info)
export interface CourseProgress extends UserProgress {
  course?: {
    title: string;
    slug: string;
    totalChapters: number;
  };
}

// Quiz Question types
export interface QuizOption {
  text: string;
  isCorrect: boolean;
}

export interface QuizQuestion {
  id: number;
  courseId: number;
  chapterId?: number;
  question: string;
  defaultQuestion: string;
  options: QuizOption[];
  category?: string;
  isActive: boolean;
}

// Flashcard types
export interface Flashcard {
  id: number;
  courseId: number;
  front: string;
  defaultFront: string;
  back: string;
  defaultBack: string;
  isActive: boolean;
}

// Interactive Simulation types
export interface InteractiveSimulation {
  id: number;
  name: string;
  description: string;
  subjectCategoryId: number;
  config: any; // Simulation configuration
  isActive: boolean;
}

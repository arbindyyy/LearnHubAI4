// Translation data for different languages

// Default translations in Hindi
export const translations = {
  // Hindi translations
  hindi: {
    meta: {
      title: 'LearnLocalHub - 21 भाषाओं में शिक्षा',
    },
    languages: {
      available: '{{count}} भाषाएँ उपलब्ध',
      viewAll: 'सभी भाषाएँ देखें',
    },
    nav: {
      home: 'होम',
      courses: 'पाठ्यक्रम',
      practice: 'अभ्यास',
      progress: 'प्रगति',
      help: 'सहायता',
      profile: 'प्रोफाइल',
    },
    sidebar: {
      categories: 'श्रेणियां',
      educationLevels: 'शैक्षिक स्तर',
    },
    hero: {
      title: 'अपनी भाषा में सीखने का आनंद लें',
      subtitle: '{{count}} भाषाओं में शैक्षिक सामग्री के साथ, हम आपको आपकी पसंदीदा भाषा में गुणवत्तापूर्ण शिक्षा प्रदान करते हैं।',
      startButton: 'अभी शुरू करें',
      learnMoreButton: 'और जानें',
    },
    progress: {
      title: 'आपकी प्रगति',
      chaptersComplete: '{{completed}}/{{total}} अध्याय पूर्ण',
      nextChapter: 'अगला अध्याय',
      lastPractice: 'पिछला अभ्यास',
      yourProgress: 'अपना प्रोग्रेस',
      noData: 'अभी तक कोई प्रगति नहीं',
      startCourse: 'अपनी शिक्षा यात्रा शुरू करने के लिए एक पाठ्यक्रम चुनें',
      browseCourses: 'पाठ्यक्रम ब्राउज़ करें',
      currentCourse: 'वर्तमान पाठ्यक्रम',
    },
    recommendedCourses: {
      title: 'आपके लिए अनुशंसित',
    },
    interactiveTools: {
      title: 'इंटरैक्टिव लर्निंग टूल्स',
    },
    tools: {
      quiz: {
        title: 'क्विज़ और प्रश्नोत्तरी',
        description: 'इंटरैक्टिव क्विज़ के साथ अपने ज्ञान का परीक्षण करें और तत्काल प्रतिक्रिया प्राप्त करें',
        action: 'क्विज़ शुरू करें',
      },
      flashcards: {
        title: 'स्मरण कार्ड',
        description: 'इंटरैक्टिव फ्लैशकार्ड्स के साथ नए शब्दों, अवधारणाओं और तथ्यों को याद रखें',
        action: 'फ्लैशकार्ड्स देखें',
      },
      simulations: {
        title: 'इंटरैक्टिव सिमुलेशन',
        description: 'विज्ञान और गणित की अवधारणाओं को वर्चुअल प्रयोगों के माध्यम से समझें',
        action: 'सिमुलेशन चलाएँ',
      },
      practice: {
        title: 'अभ्यास अध्ययन',
        description: 'अभ्यास के माध्यम से अपने ज्ञान को मजबूत करें और परीक्षा के लिए तैयार रहें',
        action: 'अभ्यास शुरू करें',
      },
    },
    course: {
      popular: 'लोकप्रिय',
      new: 'नया',
      hours: 'घंटे',
      startNow: 'अभी शुरू करें',
      chapters: 'अध्याय',
      chapter: 'अध्याय',
      curriculum: 'पाठ्यक्रम',
      overview: 'अवलोकन',
      enrollNow: 'अभी दाखिला लें',
      startLearning: 'सीखना शुरू करें',
      continueLesson: 'अध्ययन जारी रखें',
      duration: 'अवधि:',
      level: 'स्तर:',
      category: 'श्रेणी:',
      relatedCourses: 'संबंधित पाठ्यक्रम',
      reviews: 'समीक्षाएँ',
      reviewsCount: '{{count}} समीक्षाएँ',
    },
    quiz: {
      title: 'नमूना इंटरैक्टिव क्विज़',
      questionCount: 'प्रश्न {{current}}/{{total}}',
      previous: 'पिछला',
      next: 'अगला',
      submit: 'सबमिट करें',
      correctAnswer: 'सही उत्तर!',
      incorrectAnswer: 'गलत उत्तर',
      goodJob: 'बहुत अच्छा!',
      correctWas: 'सही उत्तर था: {{answer}}',
      noQuestions: 'इस पाठ्यक्रम के लिए कोई प्रश्न उपलब्ध नहीं हैं।',
    },
    benefits: {
      title: 'LearnLocalHub के लाभ',
      languages: {
        title: '21 भाषाओं में उपलब्ध',
        description: 'अपनी मातृभाषा में सीखें और समझें, जिससे सीखने की प्रक्रिया अधिक प्रभावी और आनंददायक हो',
      },
      interactive: {
        title: 'इंटरैक्टिव सीखने का अनुभव',
        description: 'क्विज़, फ्लैशकार्ड्स और सिमुलेशन के साथ ज्ञान को बेहतर ढंग से समझें और याद रखें',
      },
      tracking: {
        title: 'प्रगति ट्रैकिंग',
        description: 'अपनी शैक्षिक यात्रा का विश्लेषण करें और ट्रैक करें, जिससे आप अपनी कमजोरियों पर काम कर सकें',
      },
    },
    common: {
      viewAll: 'सभी देखें',
      loading: 'लोड हो रहा है...',
      error: 'कुछ गलत हो गया',
      tryAgain: 'पुनः प्रयास करें',
      notFound: 'नहीं मिला',
    },
  },
  
  // English translations
  english: {
    meta: {
      title: 'LearnLocalHub - Education in 21 Languages',
    },
    languages: {
      available: '{{count}} languages available',
      viewAll: 'View all languages',
    },
    nav: {
      home: 'Home',
      courses: 'Courses',
      practice: 'Practice',
      progress: 'Progress',
      help: 'Help',
      profile: 'Profile',
    },
    sidebar: {
      categories: 'Categories',
      educationLevels: 'Education Levels',
    },
    hero: {
      title: 'Enjoy Learning in Your Language',
      subtitle: 'With educational content in {{count}} languages, we provide you quality education in your preferred language.',
      startButton: 'Start Now',
      learnMoreButton: 'Learn More',
    },
    progress: {
      title: 'Your Progress',
      chaptersComplete: '{{completed}}/{{total}} chapters completed',
      nextChapter: 'Next Chapter',
      lastPractice: 'Last Practice',
      yourProgress: 'Your Progress',
      noData: 'No progress yet',
      startCourse: 'Choose a course to start your learning journey',
      browseCourses: 'Browse Courses',
      currentCourse: 'Current Course',
    },
    recommendedCourses: {
      title: 'Recommended for You',
    },
    interactiveTools: {
      title: 'Interactive Learning Tools',
    },
    tools: {
      quiz: {
        title: 'Quizzes and Tests',
        description: 'Test your knowledge with interactive quizzes and get instant feedback',
        action: 'Start Quiz',
      },
      flashcards: {
        title: 'Flashcards',
        description: 'Remember new words, concepts, and facts with interactive flashcards',
        action: 'View Flashcards',
      },
      simulations: {
        title: 'Interactive Simulations',
        description: 'Understand science and math concepts through virtual experiments',
        action: 'Run Simulation',
      },
      practice: {
        title: 'Practice Exercises',
        description: 'Strengthen your knowledge through practice and prepare for exams',
        action: 'Start Practice',
      },
    },
    course: {
      popular: 'Popular',
      new: 'New',
      hours: 'hours',
      startNow: 'Start Now',
      chapters: 'Chapters',
      chapter: 'Chapter',
      curriculum: 'Curriculum',
      overview: 'Overview',
      enrollNow: 'Enroll Now',
      startLearning: 'Start Learning',
      continueLesson: 'Continue Lesson',
      duration: 'Duration:',
      level: 'Level:',
      category: 'Category:',
      relatedCourses: 'Related Courses',
      reviews: 'Reviews',
      reviewsCount: '{{count}} reviews',
    },
    quiz: {
      title: 'Sample Interactive Quiz',
      questionCount: 'Question {{current}}/{{total}}',
      previous: 'Previous',
      next: 'Next',
      submit: 'Submit',
      correctAnswer: 'Correct Answer!',
      incorrectAnswer: 'Incorrect Answer',
      goodJob: 'Good job!',
      correctWas: 'The correct answer was: {{answer}}',
      noQuestions: 'No questions available for this course.',
    },
    benefits: {
      title: 'Benefits of LearnLocalHub',
      languages: {
        title: 'Available in 21 Languages',
        description: 'Learn and understand in your native language, making the learning process more effective and enjoyable',
      },
      interactive: {
        title: 'Interactive Learning Experience',
        description: 'Better understand and remember knowledge with quizzes, flashcards, and simulations',
      },
      tracking: {
        title: 'Progress Tracking',
        description: 'Analyze and track your educational journey, allowing you to work on your weaknesses',
      },
    },
    common: {
      viewAll: 'View All',
      loading: 'Loading...',
      error: 'Something went wrong',
      tryAgain: 'Try Again',
      notFound: 'Not Found',
    },
  },
  
  // Add more languages as needed...
};

// Function to get translations for a specific language
export const getTranslations = (language: string = 'hindi') => {
  return translations[language as keyof typeof translations] || translations.hindi;
};

// Function to format translation strings with variables
export const formatMessage = (message: string, variables: Record<string, any> = {}) => {
  return message.replace(/\{\{(\w+)\}\}/g, (_, key) => {
    return variables[key] !== undefined ? String(variables[key]) : `{{${key}}}`;
  });
};

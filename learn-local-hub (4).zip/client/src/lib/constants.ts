// Languages available in the application
export const languages = [
  { code: "hindi", name: "Hindi", nativeName: "हिंदी", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "english", name: "English", nativeName: "English", flagUrl: "https://upload.wikimedia.org/wikipedia/en/a/a4/Flag_of_the_United_Kingdom.svg" },
  { code: "marathi", name: "Marathi", nativeName: "मराठी", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "bengali", name: "Bengali", nativeName: "বাংলা", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "tamil", name: "Tamil", nativeName: "தமிழ்", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "telugu", name: "Telugu", nativeName: "తెలుగు", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "punjabi", name: "Punjabi", nativeName: "ਪੰਜਾਬੀ", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "gujarati", name: "Gujarati", nativeName: "ગુજરાતી", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "kannada", name: "Kannada", nativeName: "ಕನ್ನಡ", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "odia", name: "Odia", nativeName: "ଓଡ଼ିଆ", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "malayalam", name: "Malayalam", nativeName: "മലയാളം", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "assamese", name: "Assamese", nativeName: "অসমীয়া", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "urdu", name: "Urdu", nativeName: "اردو", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "nepali", name: "Nepali", nativeName: "नेपाली", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "konkani", name: "Konkani", nativeName: "कोंकणी", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "manipuri", name: "Manipuri", nativeName: "মৈতৈলোন্", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "sanskrit", name: "Sanskrit", nativeName: "संस्कृतम्", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "sindhi", name: "Sindhi", nativeName: "سنڌي", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "bodo", name: "Bodo", nativeName: "बड़ो", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "dogri", name: "Dogri", nativeName: "डोगरी", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" },
  { code: "kashmiri", name: "Kashmiri", nativeName: "कॉशुर", flagUrl: "https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" }
];

// Subject Categories
export const DEFAULT_SUBJECTS = [
  { code: "mathematics", name: "Mathematics", icon: "functions" },
  { code: "science", name: "Science", icon: "science" },
  { code: "history", name: "History", icon: "history_edu" },
  { code: "language", name: "Language", icon: "menu_book" },
  { code: "geography", name: "Geography", icon: "public" },
  { code: "computer_science", name: "Computer Science", icon: "computer" }
];

// Education Levels
export const DEFAULT_EDUCATION_LEVELS = [
  { code: "primary", name: "Primary (Grades 1-5)", icon: "child_care" },
  { code: "secondary", name: "Secondary (Grades 6-10)", icon: "school" },
  { code: "higher_secondary", name: "Higher Secondary (Grades 11-12)", icon: "account_balance" }
];

// Default language IDs for API requests
export const DEFAULT_LANGUAGE_ID = {
  hindi: 1,
  english: 2
};

// API Endpoints
export const API_ENDPOINTS = {
  LANGUAGES: '/api/languages',
  SUBJECTS: '/api/subjects',
  EDUCATION_LEVELS: '/api/education-levels',
  COURSES: '/api/courses',
  COURSE_DETAIL: (slug: string) => `/api/courses/${slug}`,
  COURSE_QUIZ: (courseId: number) => `/api/courses/${courseId}/quiz`,
  COURSE_FLASHCARDS: (courseId: number) => `/api/courses/${courseId}/flashcards`,
  INTERACTIVE_SIMULATIONS: '/api/interactive-simulations',
  USER_PROGRESS: '/api/user-progress',
};

// Local Storage Keys
export const STORAGE_KEYS = {
  LANGUAGE_PREFERENCE: 'learn_local_hub_language',
  USER_PROGRESS: 'learn_local_hub_progress',
  USER_SETTINGS: 'learn_local_hub_settings',
};

import { useEffect } from "react";
import { Link, useParams, useLocation } from "wouter";
import { useLanguage } from "@/hooks/use-language";
import { useCourseBySlug, useRelatedCourses, useCourseQuiz } from "@/hooks/use-courses";
import { useUserProgress, useUpdateProgress, useProgressPercentage } from "@/hooks/use-progress";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CourseCard from "@/components/CourseCard";
import QuizComponent from "@/components/QuizComponent";
import { Star, Clock, BookOpen, Award, School, Database } from "lucide-react";

const CourseDetail = () => {
  const { slug } = useParams<{ slug: string }>();
  const [_, setLocation] = useLocation();
  const { t } = useLanguage();

  // Fetch course data
  const { data: courseData, isLoading: courseLoading, error: courseError } = useCourseBySlug(slug);
  const course = courseData?.course;

  // Fetch user progress
  const { data: progressData } = useUserProgress(course?.id);
  const progress = progressData?.progress;
  const percentComplete = useProgressPercentage(progress, course?.chapters?.length);

  // Fetch related courses
  const { data: relatedCoursesData } = useRelatedCourses(course, 3);
  const relatedCourses = relatedCoursesData?.courses || [];

  // Fetch quiz questions
  const { data: quizData } = useCourseQuiz(course?.id);
  const quizQuestions = quizData?.questions || [];

  // Update progress mutation
  const updateProgress = useUpdateProgress();

  // Set document title
  useEffect(() => {
    if (course) {
      document.title = `${course.title} | LearnLocalHub`;
    }
  }, [course]);

  // Handle enrollment / continue learning
  const handleEnrollOrContinue = () => {
    if (!course) return;

    // If user hasn't started yet, mark first chapter as in progress
    if (!progress || progress.completedChapters === 0) {
      updateProgress.mutate({
        courseId: course.id,
        completedChapters: 0
      });

      // Navigate to first chapter
      if (course.chapters && course.chapters.length > 0) {
        setLocation(`/courses/${slug}/chapters/1`);
      }
    } else {
      // Navigate to next chapter
      const nextChapter = progress.completedChapters + 1;
      setLocation(`/courses/${slug}/chapters/${nextChapter}`);
    }
  };

  // Render loading state
  if (courseLoading) {
    return (
      <div className="animate-pulse">
        <div className="mb-8">
          <div className="h-60 bg-neutral-200 rounded-xl mb-6"></div>
          <div className="h-8 bg-neutral-200 rounded w-3/4 mb-4"></div>
          <div className="h-4 bg-neutral-200 rounded w-1/2 mb-2"></div>
          <div className="h-4 bg-neutral-200 rounded w-2/3 mb-6"></div>
          <div className="flex gap-3 mb-6">
            <div className="h-10 bg-neutral-200 rounded w-36"></div>
            <div className="h-10 bg-neutral-200 rounded w-36"></div>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <div className="h-10 bg-neutral-200 rounded mb-4 w-40"></div>
            <div className="h-4 bg-neutral-200 rounded mb-2 w-full"></div>
            <div className="h-4 bg-neutral-200 rounded mb-2 w-full"></div>
            <div className="h-4 bg-neutral-200 rounded mb-2 w-3/4"></div>
          </div>
          <div>
            <div className="h-40 bg-neutral-200 rounded mb-4"></div>
          </div>
        </div>
      </div>
    );
  }

  // Render error state
  if (courseError || !course) {
    return (
      <Card className="text-center p-6">
        <h2 className="text-xl font-semibold text-neutral-800 mb-3">{t('common.error')}</h2>
        <p className="text-neutral-600 mb-4">{t('common.notFound')}</p>
        <Link href="/courses">
          <Button>{t('common.viewAll')}</Button>
        </Link>
      </Card>
    );
  }

  // Render course stars
  const renderStars = (rating: number = 0) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    
    for (let i = 0; i < 5; i++) {
      if (i < fullStars) {
        stars.push(<Star key={i} className="text-secondary" fill="currentColor" />);
      } else {
        stars.push(<Star key={i} className="text-neutral-300" />);
      }
    }
    
    return (
      <div className="flex">
        {stars}
        {rating > 0 && <span className="ml-2 text-neutral-600">({rating.toFixed(1)})</span>}
      </div>
    );
  };

  return (
    <div>
      {/* Course Header */}
      <div className="bg-white rounded-xl overflow-hidden shadow-md mb-8">
        {course.imageUrl && (
          <div className="h-48 md:h-64 w-full relative">
            <img 
              src={course.imageUrl} 
              alt={course.title} 
              className="w-full h-full object-cover" 
            />
            <div className="absolute inset-0 bg-black bg-opacity-40"></div>
            <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <span className="bg-primary px-3 py-1 text-sm rounded-full">{course.category?.name}</span>
                <span className="bg-secondary px-3 py-1 text-sm rounded-full">{course.level?.name}</span>
                {course.isPopular && (
                  <span className="bg-primary-dark px-3 py-1 text-sm rounded-full">{t('course.popular')}</span>
                )}
                {course.isNew && (
                  <span className="bg-accent px-3 py-1 text-sm rounded-full">{t('course.new')}</span>
                )}
              </div>
              <h1 className="text-2xl md:text-3xl font-bold font-heading mb-2">{course.title}</h1>
              {course.rating && renderStars(course.rating)}
            </div>
          </div>
        )}
        
        <div className="p-6">
          <div className="flex flex-wrap gap-4 mb-6">
            <div className="flex items-center text-neutral-600">
              <Clock className="mr-2 h-5 w-5" />
              <span>{course.durationHours} {t('course.hours')}</span>
            </div>
            <div className="flex items-center text-neutral-600">
              <BookOpen className="mr-2 h-5 w-5" />
              <span>{course.chapters?.length || 0} {t('course.chapters')}</span>
            </div>
            <div className="flex items-center text-neutral-600">
              <Award className="mr-2 h-5 w-5" />
              <span>{course.level?.name}</span>
            </div>
          </div>
          
          {progressData?.progress ? (
            <div className="mb-6">
              <div className="flex justify-between mb-2">
                <span className="text-sm text-neutral-600">
                  {progressData.progress.completedChapters} / {course.chapters?.length || 0} {t('course.chapters')}
                </span>
                <span className="text-sm font-medium">{percentComplete}%</span>
              </div>
              <Progress value={percentComplete} className="h-2" />
            </div>
          ) : null}
          
          <div className="flex flex-wrap gap-3">
            <Button onClick={handleEnrollOrContinue} className="bg-primary hover:bg-primary-dark">
              {progress && progress.completedChapters > 0 
                ? t('course.continueLesson') 
                : t('course.startLearning')}
            </Button>
            
            {!progress && (
              <Button variant="outline" onClick={handleEnrollOrContinue}>
                {t('course.enrollNow')}
              </Button>
            )}
          </div>
        </div>
      </div>
      
      {/* Course Content */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="md:col-span-2">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="mb-6">
              <TabsTrigger value="overview">{t('course.overview')}</TabsTrigger>
              <TabsTrigger value="curriculum">{t('course.curriculum')}</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview">
              <Card>
                <CardContent className="pt-6">
                  <h2 className="text-xl font-semibold mb-4">{t('course.overview')}</h2>
                  <p className="text-neutral-700 whitespace-pre-line mb-6">{course.description}</p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
                    <div className="bg-neutral-50 p-4 rounded-lg">
                      <p className="text-sm text-neutral-500 mb-1">{t('course.duration')}</p>
                      <p className="font-medium">{course.durationHours} {t('course.hours')}</p>
                    </div>
                    <div className="bg-neutral-50 p-4 rounded-lg">
                      <p className="text-sm text-neutral-500 mb-1">{t('course.level')}</p>
                      <p className="font-medium">{course.level?.name}</p>
                    </div>
                    <div className="bg-neutral-50 p-4 rounded-lg">
                      <p className="text-sm text-neutral-500 mb-1">{t('course.category')}</p>
                      <p className="font-medium">{course.category?.name}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="curriculum">
              <Card>
                <CardContent className="pt-6">
                  <h2 className="text-xl font-semibold mb-4">{t('course.curriculum')}</h2>
                  {course.chapters && course.chapters.length > 0 ? (
                    <div className="space-y-3">
                      {course.chapters.map((chapter, index) => (
                        <div 
                          key={chapter.id} 
                          className={`p-4 rounded-lg border ${
                            progress && progress.completedChapters >= index
                              ? 'bg-primary bg-opacity-5 border-primary'
                              : 'border-neutral-200 hover:bg-neutral-50'
                          }`}
                        >
                          <div className="flex justify-between items-center">
                            <div>
                              <h3 className="font-medium">
                                {t('course.chapter')} {index + 1}: {chapter.title}
                              </h3>
                            </div>
                            {progress && progress.completedChapters >= index ? (
                              <svg 
                                xmlns="http://www.w3.org/2000/svg" 
                                className="h-5 w-5 text-primary" 
                                viewBox="0 0 20 20" 
                                fill="currentColor"
                              >
                                <path 
                                  fillRule="evenodd" 
                                  d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" 
                                  clipRule="evenodd" 
                                />
                              </svg>
                            ) : null}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-neutral-500">{t('common.notFound')}</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
        
        {/* Course Sidebar */}
        <div>
          <Card className="mb-6">
            <CardContent className="pt-6">
              <h2 className="text-lg font-semibold mb-4">{t('course.relatedCourses')}</h2>
              <div className="space-y-4">
                {relatedCourses.length > 0 ? (
                  relatedCourses.map((relatedCourse) => (
                    <Link key={relatedCourse.id} href={`/courses/${relatedCourse.slug}`}>
                      <div className="flex items-center gap-3 hover:bg-neutral-50 p-2 rounded-lg cursor-pointer">
                        <div className="w-16 h-16 bg-primary-light rounded overflow-hidden">
                          {relatedCourse.imageUrl ? (
                            <img 
                              src={relatedCourse.imageUrl} 
                              alt={relatedCourse.title} 
                              className="w-full h-full object-cover" 
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-white">
                              <span>{relatedCourse.title.charAt(0)}</span>
                            </div>
                          )}
                        </div>
                        <div>
                          <h3 className="font-medium text-sm line-clamp-2">{relatedCourse.title}</h3>
                          <p className="text-xs text-neutral-500">{relatedCourse.durationHours} {t('course.hours')}</p>
                        </div>
                      </div>
                    </Link>
                  ))
                ) : (
                  <p className="text-neutral-500 text-sm">{t('common.notFound')}</p>
                )}
              </div>
            </CardContent>
          </Card>
          
          {/* Quiz Preview */}
          {quizQuestions.length > 0 && (
            <Card>
              <CardContent className="pt-6">
                <h2 className="text-lg font-semibold mb-4">{t('quiz.title')}</h2>
                <p className="text-neutral-600 text-sm mb-4">
                  {t('quiz.questionCount', { current: 1, total: quizQuestions.length })}
                </p>
                <Button 
                  className="w-full"
                  onClick={() => setLocation(`/courses/${slug}/quiz`)}
                >
                  {t('tools.quiz.action')}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default CourseDetail;

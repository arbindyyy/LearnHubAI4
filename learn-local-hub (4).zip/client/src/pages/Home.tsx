import { useEffect } from "react";
import { Link } from "wouter";
import { useLanguage } from "@/hooks/use-language";
import { useQuery } from "@tanstack/react-query";
import CourseCard from "@/components/CourseCard";
import ProgressTracker from "@/components/ProgressTracker";
import InteractiveTools from "@/components/InteractiveTools";
import QuizComponent from "@/components/QuizComponent";
import { Course } from "@/lib/types";
import { ArrowRight, ArrowLeft } from "lucide-react";

const Home = () => {
  const { t, languageId } = useLanguage();

  // Fetch recommended courses
  const { data: coursesData, isLoading: coursesLoading } = useQuery({
    queryKey: [`/api/courses?languageId=${languageId}&isPopular=true&limit=4`],
  });

  // Fetch quiz questions for sample quiz
  const { data: quizData } = useQuery({
    queryKey: [`/api/courses/1/quiz?languageId=${languageId}`],
  });

  // Automatically set document title based on current language
  useEffect(() => {
    document.title = t('meta.title');
  }, [t]);

  const recommendedCourses: Course[] = coursesData?.courses || [];
  const quizQuestions = quizData?.questions || [];

  return (
    <>
      {/* Hero Section */}
      <section className="mb-8">
        <div className="bg-primary rounded-xl p-6 md:p-8 shadow-lg text-white relative overflow-hidden hero-gradient">
          <div className="max-w-xl relative z-10">
            <h1 className="font-heading text-2xl md:text-3xl lg:text-4xl font-bold mb-3">
              {t('hero.title')}
            </h1>
            <p className="mb-6 text-lg opacity-90">
              {t('hero.subtitle', { count: 21 })}
            </p>
            <div className="flex flex-wrap gap-4">
              <Link href="/courses" className="px-6 py-3 bg-white text-primary font-medium rounded-lg hover:bg-neutral-100 shadow-md transition-colors">
                {t('hero.startButton')}
              </Link>
              <Link href="/about" className="px-6 py-3 bg-primary-dark bg-opacity-30 text-white font-medium rounded-lg border border-white border-opacity-30 hover:bg-opacity-50 transition-colors">
                {t('hero.learnMoreButton')}
              </Link>
            </div>
          </div>
          
          {/* Decorative elements */}
          <div className="absolute right-8 bottom-8 text-white text-opacity-10">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-24 w-24" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5zm0 0v8" />
            </svg>
          </div>
        </div>
      </section>

      {/* Current Learning Path */}
      <section className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-heading text-xl font-semibold text-neutral-800">{t('progress.title')}</h2>
          <Link href="/progress" className="text-sm text-primary hover:underline">
            {t('common.viewAll')}
          </Link>
        </div>
        
        <ProgressTracker />
      </section>

      {/* Recommended Courses */}
      <section className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-heading text-xl font-semibold text-neutral-800">{t('recommendedCourses.title')}</h2>
          <div className="flex gap-2">
            <button className="p-1 rounded-full hover:bg-neutral-200">
              <ArrowLeft className="h-5 w-5" />
            </button>
            <button className="p-1 rounded-full hover:bg-neutral-200">
              <ArrowRight className="h-5 w-5" />
            </button>
          </div>
        </div>
        
        {coursesLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-white rounded-xl shadow-md overflow-hidden animate-pulse">
                <div className="h-40 bg-neutral-200"></div>
                <div className="p-4">
                  <div className="h-4 bg-neutral-200 rounded w-3/4 mb-2"></div>
                  <div className="h-6 bg-neutral-200 rounded mb-2"></div>
                  <div className="h-4 bg-neutral-200 rounded mb-4"></div>
                  <div className="flex justify-between">
                    <div className="h-4 bg-neutral-200 rounded w-1/4"></div>
                    <div className="h-4 bg-neutral-200 rounded w-1/4"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {recommendedCourses.map((course) => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        )}
      </section>

      {/* Interactive Learning Tools */}
      <section className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-heading text-xl font-semibold text-neutral-800">{t('interactiveTools.title')}</h2>
          <Link href="/tools" className="text-sm text-primary hover:underline">
            {t('common.viewAll')}
          </Link>
        </div>
        
        <InteractiveTools />
      </section>

      {/* Sample Interactive Quiz */}
      {quizQuestions.length > 0 && (
        <section className="mb-8">
          <QuizComponent 
            questions={quizQuestions}
            onComplete={(score, total) => {
              console.log(`Quiz completed! Score: ${score}/${total}`);
            }}
          />
        </section>
      )}

      {/* Benefits Section */}
      <section className="mb-8">
        <h2 className="font-heading text-xl font-semibold text-neutral-800 mb-4">{t('benefits.title')}</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-5 rounded-xl shadow-sm">
            <div className="h-12 w-12 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129" />
              </svg>
            </div>
            <h3 className="font-heading font-semibold text-lg mb-2">{t('benefits.languages.title')}</h3>
            <p className="text-neutral-600">
              {t('benefits.languages.description')}
            </p>
          </div>
          
          <div className="bg-white p-5 rounded-xl shadow-sm">
            <div className="h-12 w-12 bg-secondary bg-opacity-10 rounded-full flex items-center justify-center mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A13.916 13.916 0 008 11a4 4 0 118 0c0 1.017-.07 2.019-.203 3m-2.118 6.844A21.88 21.88 0 0015.171 17m3.839 1.132c.645-2.266.99-4.659.99-7.132A8 8 0 008 4.07M3 15.364c.64-1.319 1-2.8 1-4.364 0-1.457.39-2.823 1.07-4" />
              </svg>
            </div>
            <h3 className="font-heading font-semibold text-lg mb-2">{t('benefits.interactive.title')}</h3>
            <p className="text-neutral-600">
              {t('benefits.interactive.description')}
            </p>
          </div>
          
          <div className="bg-white p-5 rounded-xl shadow-sm">
            <div className="h-12 w-12 bg-accent bg-opacity-10 rounded-full flex items-center justify-center mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
            </div>
            <h3 className="font-heading font-semibold text-lg mb-2">{t('benefits.tracking.title')}</h3>
            <p className="text-neutral-600">
              {t('benefits.tracking.description')}
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;

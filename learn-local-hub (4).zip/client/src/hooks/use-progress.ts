import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { API_ENDPOINTS } from '@/lib/constants';
import { CourseProgress } from '@/lib/types';

// Hook for fetching user progress
export const useUserProgress = (courseId?: number) => {
  return useQuery({
    queryKey: [
      `${API_ENDPOINTS.USER_PROGRESS}${courseId ? `?courseId=${courseId}` : ''}`
    ],
  });
};

// Hook for updating user progress
export const useUpdateProgress = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ courseId, completedChapters }: { courseId: number, completedChapters: number }) => {
      const res = await apiRequest('POST', API_ENDPOINTS.USER_PROGRESS, { courseId, completedChapters });
      const data = await res.json();
      return data;
    },
    onSuccess: (data) => {
      // Invalidate queries to refetch the latest progress data
      queryClient.invalidateQueries({ queryKey: [API_ENDPOINTS.USER_PROGRESS] });
      
      // If we have a courseId, invalidate that specific query too
      if (data?.progress?.courseId) {
        queryClient.invalidateQueries({ 
          queryKey: [`${API_ENDPOINTS.USER_PROGRESS}?courseId=${data.progress.courseId}`] 
        });
      }
    },
  });
};

// Hook for calculating progress percentage
export const useProgressPercentage = (progress?: CourseProgress, totalChapters?: number) => {
  if (!progress || !progress.completedChapters) {
    return 0;
  }
  
  const total = totalChapters || 12; // Default if not provided
  return Math.round((progress.completedChapters / total) * 100);
};

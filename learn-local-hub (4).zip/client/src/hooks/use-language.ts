import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { getTranslations, formatMessage } from '@/lib/i18n';
import { STORAGE_KEYS, languages as availableLanguages, DEFAULT_LANGUAGE_ID } from '@/lib/constants';

interface LanguageContextType {
  currentLanguage: string;
  languageId: number;
  setLanguage: (lang: string) => void;
  t: (key: string, variables?: Record<string, any>) => string;
  languages: typeof availableLanguages;
}

const LanguageContext = createContext<LanguageContextType>({
  currentLanguage: 'hindi',
  languageId: DEFAULT_LANGUAGE_ID.hindi,
  setLanguage: () => {},
  t: (key) => key,
  languages: availableLanguages,
});

interface LanguageProviderProps {
  children: ReactNode;
  defaultLanguage?: string;
}

export const LanguageProvider = ({ children, defaultLanguage = 'hindi' }: LanguageProviderProps) => {
  // Initialize with saved language preference or default
  const [currentLanguage, setCurrentLanguage] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem(STORAGE_KEYS.LANGUAGE_PREFERENCE);
      return saved || defaultLanguage;
    }
    return defaultLanguage;
  });

  // Get language ID (for API calls)
  const languageId = currentLanguage === 'english' 
    ? DEFAULT_LANGUAGE_ID.english 
    : DEFAULT_LANGUAGE_ID.hindi;

  // Update localStorage when language changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LANGUAGE_PREFERENCE, currentLanguage);
  }, [currentLanguage]);

  // Translation function
  const t = (key: string, variables: Record<string, any> = {}) => {
    // Split the key by dots to access nested properties
    const keys = key.split('.');
    const translations = getTranslations(currentLanguage);
    
    // Navigate through the nested object
    let value = translations;
    for (const k of keys) {
      if (!value || typeof value !== 'object') {
        return key; // Return the key if the path doesn't exist
      }
      value = value[k as keyof typeof value];
    }
    
    if (typeof value !== 'string') {
      return key; // Return the key if the value is not a string
    }
    
    return formatMessage(value, variables);
  };

  const setLanguage = (lang: string) => {
    if (availableLanguages.some(l => l.code === lang)) {
      setCurrentLanguage(lang);
    }
  };

  const contextValue = {
    currentLanguage,
    languageId,
    setLanguage,
    t,
    languages: availableLanguages
  };
  
  return React.createElement(
    LanguageContext.Provider,
    { value: contextValue },
    children
  );
};

export const useLanguage = () => useContext(LanguageContext);

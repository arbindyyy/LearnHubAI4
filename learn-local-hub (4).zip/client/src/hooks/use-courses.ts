import { useQuery } from '@tanstack/react-query';
import { API_ENDPOINTS } from '@/lib/constants';
import { useLanguage } from './use-language';
import { Course } from '@/lib/types';

// Hook for fetching recommended courses
export const useRecommendedCourses = (limit: number = 4) => {
  const { languageId } = useLanguage();
  
  return useQuery({
    queryKey: [`${API_ENDPOINTS.COURSES}?languageId=${languageId}&isPopular=true&limit=${limit}`],
  });
};

// Hook for fetching courses by category
export const useCoursesByCategory = (categoryId?: number, limit?: number) => {
  const { languageId } = useLanguage();
  
  return useQuery({
    queryKey: [
      `${API_ENDPOINTS.COURSES}?languageId=${languageId}${categoryId ? `&categoryId=${categoryId}` : ''}${limit ? `&limit=${limit}` : ''}`
    ],
    enabled: !!languageId,
  });
};

// Hook for fetching courses by level
export const useCoursesByLevel = (levelId?: number, limit?: number) => {
  const { languageId } = useLanguage();
  
  return useQuery({
    queryKey: [
      `${API_ENDPOINTS.COURSES}?languageId=${languageId}${levelId ? `&levelId=${levelId}` : ''}${limit ? `&limit=${limit}` : ''}`
    ],
    enabled: !!languageId,
  });
};

// Hook for fetching new courses
export const useNewCourses = (limit: number = 4) => {
  const { languageId } = useLanguage();
  
  return useQuery({
    queryKey: [`${API_ENDPOINTS.COURSES}?languageId=${languageId}&isNew=true&limit=${limit}`],
  });
};

// Hook for fetching a single course by slug
export const useCourseBySlug = (slug?: string) => {
  const { languageId } = useLanguage();
  
  return useQuery({
    queryKey: [slug ? API_ENDPOINTS.COURSE_DETAIL(slug) + `?languageId=${languageId}` : null],
    enabled: !!slug && !!languageId,
  });
};

// Hook for fetching course quiz questions
export const useCourseQuiz = (courseId?: number) => {
  const { languageId } = useLanguage();
  
  return useQuery({
    queryKey: [courseId ? API_ENDPOINTS.COURSE_QUIZ(courseId) + `?languageId=${languageId}` : null],
    enabled: !!courseId && !!languageId,
  });
};

// Hook for fetching course flashcards
export const useCourseFlashcards = (courseId?: number) => {
  const { languageId } = useLanguage();
  
  return useQuery({
    queryKey: [courseId ? API_ENDPOINTS.COURSE_FLASHCARDS(courseId) + `?languageId=${languageId}` : null],
    enabled: !!courseId && !!languageId,
  });
};

// Hook for fetching related courses (by category)
export const useRelatedCourses = (course?: Course, limit: number = 3) => {
  const { languageId } = useLanguage();
  
  return useQuery({
    queryKey: [
      course 
        ? `${API_ENDPOINTS.COURSES}?languageId=${languageId}&categoryId=${course.subjectCategoryId}&limit=${limit}` 
        : null
    ],
    enabled: !!course && !!languageId,
    select: (data) => {
      // Filter out the current course from related courses
      const courses = data?.courses || [];
      return {
        ...data,
        courses: courses.filter(c => c.id !== course?.id)
      };
    }
  });
};
